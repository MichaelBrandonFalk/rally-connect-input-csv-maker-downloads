Rally Connect Input CSV Maker for Linux Mint x64

Recommended: install the provided .deb package by double-clicking it in Linux
Mint, or run: sudo apt install ./<package-name>.deb

Portable archive: extract the entire archive, then double-click
Launch Rally Connect Input CSV Maker.sh. If Mint asks, choose Run.

The app is built on Ubuntu 22.04 for compatibility with Linux Mint 21 and newer
on 64-bit Intel/AMD systems. Python is bundled with the app.
