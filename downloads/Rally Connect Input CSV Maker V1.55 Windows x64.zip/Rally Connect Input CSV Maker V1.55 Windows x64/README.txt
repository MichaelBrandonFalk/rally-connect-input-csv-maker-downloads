Rally Connect Input CSV Maker for Windows x64

1. Extract the entire folder before running the app.
2. Open the app folder.
3. Double-click rally-connect-input-csv-maker.exe.

The app is self-contained and does not require Python or Excel to be installed.
Keep the _internal folder beside the executable.

Windows may show a SmartScreen warning because this build is not signed with a
commercial Windows code-signing certificate.
